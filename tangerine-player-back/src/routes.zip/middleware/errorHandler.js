export const errorHandler = (err, req, res, next) => {
    console.error('Error:', err);
    
    // Handle Prisma specific errors
    if (err.code) {
      switch (err.code) {
        case 'P2002':
          return res.status(400).json({ 
            error: 'Unique constraint violation',
            message: 'A record with this value already exists' 
          });
        case 'P2025':
          return res.status(404).json({ 
            error: 'Record not found', 
            message: 'The requested record does not exist' 
          });
        default:
          break;
      }
    }
  
    // Default error response
    const statusCode = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';
    
    res.status(statusCode).json({
      error: true,
      message,
      stack: process.env.NODE_ENV === 'production' ? undefined : err.stack
    });
  };
  
  // Custom error class
  export class ApiError extends Error {
    constructor(message, statusCode) {
      super(message);
      this.statusCode = statusCode;
    }
  }